package com.example.project.Characters;

import com.example.project.Cultures.DefenderSponge;

public class KingSpongalry implements Ferengi{

    public KingSpongalry(int i){
        System.out.println("The king never surrenders.");
    }

    @Override
    public boolean secretPower(int enemyModifier) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'enterNegotiation'");
    }
    
}