package com.example.project.Characters;

import com.example.project.Cultures.Gary_Indiana;

public class Gary implements Gary_Indiana{

    public Gary(int i){

    }
}