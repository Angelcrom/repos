package com.example.project.Characters;

import com.example.project.Cultures.meow;

public class lily implements meow {

    public lily(int i){
        System.out.println("lily is in the mood to " + diplomacyStates.values() + ".");
    }
    @Override
    public boolean tryDiplomacy(int enemyModifier) {
        throw new
    }
}
