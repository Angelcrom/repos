package com.example.project.Characters;

import com.example.project.Cultures.FishFolk;

public class MantaRay implements FishFolk {

    public boolean attemptNegotiation{
        return True;
    }
}