package com.example.project.Characters;

import com.example.project.Cultures.Naboo;

public class Zagara implements Zerg
    
    public Zagaraa(int i) {
        System.out.println("Queen Amidala is in the mood to " + diplomacyStates.values()[i] + ".");
    }

    @Override
    public boolean tryDiplomacy(int enemyModifier) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'tryDiplomacy'");
    }

    @Override
    public boolean Defend(int enemyModifier) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'fight'");
    }

    @Override
    public boolean trytoDiscussPeace(int enemyModifier) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'tryToDiscussPeace'");
    }

    @Override
    public boolean trytoDecieve(int enemyModifier) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'tryToDecieve'");
    }
}