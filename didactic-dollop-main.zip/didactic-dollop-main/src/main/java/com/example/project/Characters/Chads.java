package com.example.project.Characters;

import com.example.project.Cultures.TexasRangers;

public class Chad implements TexasRangers {



    }
}


